import torch
import torch.nn.functional as F
import argparse
import os
import baselineUtils
from transformers import BertModel, BertConfig
from individual_TF import LinearEmbedding as NewEmbed, Generator as GeneratorTS
from torch.utils.data import DataLoader

def test(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 🔹 경로 설정
    model_path = os.path.join("models/BERT", args.name, f"{int(args.epoch):05}.pth")
    save_path = os.path.join("output/BERT", args.name)
    os.makedirs(save_path, exist_ok=True)

    # 🔹 데이터셋 로드
    val_dataset, _ = baselineUtils.create_dataset(
        args.dataset_folder,
        args.dataset_name,
        val_size=0,
        gt=args.obs,
        horizon=args.preds,
        delim=args.delim,
        train=False,
        eval=True,
        verbose=True
    )

    val_loader = DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False)

    # 🔹 모델 정의
    embedding_layer = NewEmbed(3, 768).to(device)
    model = BertModel(BertConfig()).to(device)
    generator = GeneratorTS(768, 2).to(device)

    # 🔹 학습된 가중치 로드
    checkpoint = torch.load(model_path, map_location=device)
    embedding_layer.load_state_dict(checkpoint['embedding'])
    model.load_state_dict(checkpoint['bert'])
    generator.load_state_dict(checkpoint['generator'])

    model.eval()
    embedding_layer.eval()
    generator.eval()

    # 🔹 지표 저장 리스트
    ADE, FDE, MAD, FAD = [], [], [], []

    with torch.no_grad():
        for batch in val_loader:
            src = batch['src'][:, :, 2:4].to(device)  # (B, obs, 2)
            trg = batch['trg'][:, :, 2:4].to(device)  # (B, preds, 2)

            inp_cls = torch.ones(src.shape[0], src.shape[1], 1).to(device)
            trg_cls = torch.zeros(trg.shape[0], trg.shape[1], 1).to(device)
            net_input = torch.cat((torch.cat((src, trg), 1), torch.cat((inp_cls, trg_cls), 1)), 2)

            net_input = embedding_layer(net_input)

            position = torch.arange(0, net_input.shape[1]).repeat(src.shape[0], 1).long().to(device)
            token = torch.zeros((src.shape[0], net_input.shape[1])).long().to(device)
            attention_mask = torch.ones((src.shape[0], net_input.shape[1])).long().to(device)

            out = model(inputs_embeds=net_input,
                        position_ids=position,
                        token_type_ids=token,
                        attention_mask=attention_mask)

            pred = generator(out.last_hidden_state)  # (B, obs+pred, 2)

            # 정답 trajectory (src + trg)
            gt = torch.cat((src, trg), 1)

            # 🔸 ADE: 전체 시점 평균 거리
            ade = F.pairwise_distance(pred.view(-1, 2), gt.view(-1, 2)).mean()
            ADE.append(ade.item())

            # 🔸 FDE: 마지막 시점 평균 거리
            fde = F.pairwise_distance(pred[:, -1], gt[:, -1]).mean()
            FDE.append(fde.item())

            # 🔸 MAD: 각 trajectory마다 ADE
            ade_per_traj = F.pairwise_distance(pred, gt).mean(dim=1)  # (B,)
            MAD.extend(ade_per_traj.cpu().tolist())

            # 🔸 FAD: 각 trajectory마다 FDE
            fde_per_traj = F.pairwise_distance(pred[:, -1], gt[:, -1])  # (B,)
            FAD.extend(fde_per_traj.cpu().tolist())

    # 🔹 최종 지표 출력
    print(f"✓ Inference Complete - ADE: {sum(ADE)/len(ADE):.4f}, FDE: {sum(FDE)/len(FDE):.4f}")
    mad = sum(MAD) / len(MAD)
    fad = sum(FAD) / len(FAD)

    print("=" * 40)
    print(f"✓ Evaluation Results for {args.name}")
    print(f"→ ADE (Average Displacement Error): {sum(ADE)/len(ADE):.4f}")
    print(f"→ FDE (Final Displacement Error): {sum(FDE)/len(FDE):.4f}")
    print(f"→ MAD (Mean ADE per trajectory): {mad:.4f}")
    print(f"→ FAD (Mean FDE per trajectory): {fad:.4f}")
    print("=" * 40)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset_folder', type=str, default='datasets')
    parser.add_argument('--dataset_name', type=str, default='eth')
    parser.add_argument('--name', type=str, default='eth_BERT')
    parser.add_argument('--epoch', type=int, default=99)
    parser.add_argument('--batch_size', type=int, default=256)
    parser.add_argument('--obs', type=int, default=8)
    parser.add_argument('--preds', type=int, default=12)
    parser.add_argument('--delim', type=str, default='\t')
    args = parser.parse_args()

    test(args)
