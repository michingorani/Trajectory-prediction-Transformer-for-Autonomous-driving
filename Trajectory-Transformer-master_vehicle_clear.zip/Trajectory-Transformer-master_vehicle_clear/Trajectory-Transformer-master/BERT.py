import argparse
import baselineUtils
import torch
import torch.utils.data
import torch.nn as nn
import torch.nn.functional as F
import os
import time
from transformer.batch import subsequent_mask
from torch.optim import Adam
from transformer.noam_opt import NoamOpt
import numpy as np
import scipy.io
from torch.utils.tensorboard import SummaryWriter
from transformers import BertModel, BertConfig
from individual_TF import LinearEmbedding as NewEmbed, Generator as GeneratorTS


def main():
    parser = argparse.ArgumentParser(description='Train the BERT-based trajectory predictor')
    parser.add_argument('--dataset_folder', type=str, default='datasets')
    parser.add_argument('--dataset_name', type=str, default='zara1')
    parser.add_argument('--obs', type=int, default=8)
    parser.add_argument('--preds', type=int, default=12)
    parser.add_argument('--batch_size', type=int, default=256)
    parser.add_argument('--max_epoch', type=int, default=100)
    parser.add_argument('--delim', type=str, default='\t')
    parser.add_argument('--name', type=str, default="zara1")
    parser.add_argument('--cpu', action='store_true')
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() and not args.cpu else "cpu")

    os.makedirs(f'models/BERT/{args.name}', exist_ok=True)
    os.makedirs(f'output/BERT/{args.name}', exist_ok=True)
    log = SummaryWriter(f'logs/BERT_{args.name}')

    train_dataset, _ = baselineUtils.create_dataset(args.dataset_folder, args.dataset_name, 0, args.obs, args.preds,
                                                    delim=args.delim, train=True, verbose=True)
    val_dataset, _ = baselineUtils.create_dataset(args.dataset_folder, args.dataset_name, 0, args.obs, args.preds,
                                                  delim=args.delim, train=False, verbose=True)

    tr_dl = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=0)
    val_dl = torch.utils.data.DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False, num_workers=0)

    # Model and optimizer setup
    embedding_layer = NewEmbed(3, 768).to(device)
    model = BertModel(BertConfig()).to(device)
    generator = GeneratorTS(768, 2).to(device)
    optim = NoamOpt(768, 0.1, len(tr_dl),
                    torch.optim.Adam(list(embedding_layer.parameters()) + list(model.parameters()) + list(generator.parameters()),
                                     lr=0, betas=(0.9, 0.98), eps=1e-9))

    mean = train_dataset[:]['src'][:, :, 2:4].mean((0, 1)) * 0
    std = train_dataset[:]['src'][:, :, 2:4].std((0, 1)) * 0 + 1

    for epoch in range(args.max_epoch):
        model.train()
        epoch_loss = 0

        for id_b, batch in enumerate(tr_dl):
            optim.optimizer.zero_grad()

            inp = ((batch['src'][:, :, 2:4] - mean) / std).to(device)
            trg_masked = torch.zeros((inp.shape[0], args.preds, 2)).to(device)
            inp_cls = torch.ones(inp.shape[0], inp.shape[1], 1).to(device)
            trg_cls = torch.zeros(trg_masked.shape[0], trg_masked.shape[1], 1).to(device)
            inp_cat = torch.cat((inp, trg_masked), 1)
            cls_cat = torch.cat((inp_cls, trg_cls), 1)
            net_input = torch.cat((inp_cat, cls_cat), 2)  # [batch, seq_len, 3]

            net_input = embedding_layer(net_input)  # [batch, seq_len, 768]

            position = torch.arange(0, net_input.shape[1]).repeat(inp.shape[0], 1).long().to(device)
            token = torch.zeros((inp.shape[0], net_input.shape[1])).long().to(device)
            attention_mask = torch.ones((inp.shape[0], net_input.shape[1])).long().to(device)

            out = model(inputs_embeds=net_input,
                        position_ids=position,
                        token_type_ids=token,
                        attention_mask=attention_mask)

            pred = generator(out.last_hidden_state)

            target_full = torch.cat((batch['src'][:, :, 2:4], batch['trg'][:, :, 2:4]), 1).to(device)
            target_full = (target_full - mean.to(device)) / std.to(device)

            loss = F.pairwise_distance(pred.view(-1, 2), target_full.view(-1, 2)).mean()
            loss.backward()
            optim.step()

            print(f"epoch {epoch:03}/{args.max_epoch}  batch {id_b:04}/{len(tr_dl)}  loss: {loss.item():.4f}")
            epoch_loss += loss.item()

        log.add_scalar('Loss/train', epoch_loss / len(tr_dl), epoch)

        # ✅ 저장 부분 추가
        torch.save({
            'embedding': embedding_layer.state_dict(),
            'bert': model.state_dict(),
            'generator': generator.state_dict(),
        }, f"models/BERT/{args.name}/{epoch:05}.pth")

if __name__ == '__main__':
    main()
